
#include ".\page.h"

CPage::CPage(void)
{
}

CPage::~CPage(void)
{
}


